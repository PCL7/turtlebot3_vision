#!/usr/bin/env python
from __future__ import print_function
# python script that subscribes to compressed images finds the face, then
#publishes to turtle_commands
import rospy
import cv2 as cv
import argparse
import sys
import numpy as np
from std_msgs.msg import UInt16
from sensor_msgs.msg import CompressedImage
class see_command:

    def __init__ (self):
        self.center = 640
        self.pub = rospy.Publisher("turtle_commands",UInt16, queue_size =1)
        self.sub = rospy.Subscriber("/raspicam_node/image/compressed",
                CompressedImage, self.detect_then_command, queue_size =1)
        self.face_cascade = cv.CascadeClassifier('/home/m535816/catkin_ws/opencv-4.1.0/data/haarcascades/haarcascade_frontalface_default.xml')
    def detect_then_command (self, ros_data):
        screen_center = self.center
        #frame_gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        #frame_gray = cv.equalizeHist(frame_gray)

        #test
        np_arr = np.fromstring(ros_data.data,np.uint8)
        image_np = cv.imdecode(np_arr,cv.IMREAD_COLOR)
        #color convert
        img_np_gray = cv.cvtColor(image_np,cv.COLOR_BGR2GRAY)
        #-- Detect faces

        faces = self.face_cascade.detectMultiScale(img_np_gray, 1.3, 5)
        eye_center = 0
        for (x,y,w,h) in faces:
            cv.rectangle(image_np,(x,y),(x+w,y+h),(255,0,0),2)
            roi_gray = img_np_gray[y:y+h, x:x+w]
            roi_color = image_np[y:y+h, x:x+w]
            eye_center = x+w/2
        #cv.imshow('img',image_np)
        self.pub.publish(eye_center)
        #cv.waitKey(0)
        #rospy.sleep(20.)
        #cv.destroyAllWindows()

def main (args):
    sc = see_command()
    rospy.init_node('see_command',anonymous=True)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print ("shutting down ic")

if __name__=='__main__':
    main (sys.argv)
