#!/usr/bin/env python
import rospy
from std_msgs.msg import UInt16

#moves the turtle based on
class turtle_move ():
    """docstring for turtle_move"""
    def __init__(self):
        # initiliaze
        rospy.init_node('turtle_move', anonymous=False)
        # tell user how to stop TurtleBot
        rospy.loginfo("To stop TurtleBot CTRL + C")

        # What function to call when you ctrl + c
        rospy.on_shutdown(self.shutdown)

        # Create a publisher which can "talk" to TurtleBot and tell it to move
        # Tip: You may need to change cmd_vel_mux/input/navi to /cmd_vel if you're not using TurtleBot
        self.cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)

        #TurtleBot will stop if we don't keep telling it to move.  How often should we tell it to move? 10 HZ
        r = rospy.Rate(10);

        # Twist is a datatype for velocity
        self.move_cmd = Twist()
        stay_still()
        #rospy.Subscriber("turtle_command",int, make_move)

        # as long as you haven't ctrl + c keeping doing...
        while not rospy.is_shutdown():

            stay_still()
            rospy.Subscriber("turtle_command",UInt16, make_move)
            # publish the velocity
            self.cmd_vel.publish(move_cmd)

            # wait for 0.1 seconds (10 HZ) and publish again
            r.sleep()

    def stay_still (self):

        self.move_cmd.linear.x=0
        self.move_cmd.angular.z=0

    def make_move (self, cent_x):
        screen_x = 640
        self.move_cmd.linear.x = .2
        if cent_x < screen_x+5:
            self.move_cmd.angular.z = -1
        elif cent_x > (screen_x+5):
            self.move_cmd.angular.z = 1
        else:
            self.move_cmd.angular.z = 0
        if cent_x==0:
            stay_still()


if __name__ == "__main__":
    try:
        turtle_move()
    except:
        rospy.loginfo("turtle_move terminated.")
