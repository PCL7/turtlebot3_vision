#!/usr/bin/env python
from __future__ import print_function
# python script that subscribes to compressed images finds the face, then
#publishes to turtle_commands
import rospy
import cv2 as cv
import argparse
import sys
import numpy as np
from std_msgs.msg import UInt16
from sensor_msgs.msg import CompressedImage
class see_command:

    def __init__ (self):
        self.center = 640
        self.pub = rospy.Publisher("turtle_commands",UInt16)
        self.sub = rospy.Subscriber("/raspicam_node/image/compressed",
                CompressedImage, self.detect_then_command, queue_size =1)
        self.face_cascade = cv.CascadeClassifier('~/catkin_ws/opencv-4.1.0/data/haarcascades/haarcascade_frontalface_default.xml')
        self.eye_cascade = cv.CascadeClassifier('~/catkin_ws/opencv-4.1.0/data/haarcascades/haarcascade_eye.xml')
    def detect_then_command (self, ros_data):
        print("dtc \n")
        screen_center = self.center
        #frame_gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        #frame_gray = cv.equalizeHist(frame_gray)

        #test
        np_arr = np.fromstring(ros_data.data,np.uint8)
        image_np = cv.imdecode(np_arr,cv.IMREAD_COLOR)
        #color convert
        img_np_grey = cv.cvtColor(image_np,cv.COLOR_BGR2GRAY)
        #-- Detect faces
        faces = self.face_cascade.detectMultiScale(img_np_grey, 1.3,5)
        for (x,y,w,h) in faces:
            center = (x + w//2, y + h//2)
            #-- In each face, detect eyes
            eyes = self.eyes_cascade.detectMultiScale(faceROI)
            eye_center = 0
            for (x2,y2,w2,h2) in eyes:
                eye_center += (x + x2 + w2//2)
            eye_center = eye_center/2
        #passes face center to bot
        self.pub.publish(eye_center)
        print("in there")
        #turtle_move.make_move(eye_center,screen_center)
def main (args):
    sc = see_command()
    rospy.init_node('see_command',anonymous=True)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print ("shutting down ic")

if __name__=='__main__':
    main (sys.argv)
