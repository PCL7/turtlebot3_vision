#!/usr/bin/env python
import rospy
from std_msgs.msg import UInt16
from geometry_msgs.msg import Twist
from math import log
VERBOSE = False
#moves the turtle based on
class turtle_move ():
    """docstring for turtle_move"""
    def __init__(self):
        # initiliaze")
        rospy.init_node('turtle_movething', anonymous=False)
        # tell user how to stop TurtleBot")
        rospy.loginfo("To stop TurtleBot CTRL + C")

        # What function to call when you ctrl + c
        rospy.on_shutdown(self.stay_still)
        # Create a publisher which can "talk" to TurtleBot and tell it to move
        # Tip: You may need to change cmd_vel_mux/input/navi to /cmd_vel if you're not using TurtleBot
        self.cmd_vel = rospy.Publisher('cmd_vel', Twist, queue_size=10)

        #TurtleBot will stop if we don't keep telling it to move.  How often should we tell it to move? 10 HZ
        self.r = rospy.Rate(10);
        # Twist is a datatype for velocity
        self.move_cmd = Twist()
        #stay_still()

        rospy.Subscriber("turtle_commands",UInt16,self.make_move)
        # as long as you haven't ctrl + c keeping doing...
        while not rospy.is_shutdown():

            #self.stay_still()
            # publish the velocity
            #self.cmd_vel.publish(self.move_cmd)

            # wait for 0.1 seconds (10 HZ) and publish again
            self.r.sleep()

    #sets movement to 0 and publishes
    def shutdown(self):
        self.stay_still()
        self.cmd_vel.publish(self.move_cmd)
        print("shutdown")
        rospy.sleep(1.)
    #sets movement to 0
    def stay_still (self):
        self.move_cmd.linear.x=0
        self.move_cmd.angular.z=0

    #if 0 => no detect
    #elif within error of middle, then straight
    #else moves straight and with "degree" angular velocity
    #with degree smaller if closer to middle and greater otherwise
    def make_move (self, msg_cent_x):
        cent_x=msg_cent_x.data
        if VERBOSE:
            print (cent_x)
        screen_x = 640
        if cent_x==0:
            self.stay_still()
            return
        error = 50
        diff = abs(cent_x-screen_x)
        degree =0
        if diff> error:
            degree = log(diff,300)
            degree = degree -.5
            degree = abs(degree)

        if VERBOSE:
            print (degree)
        self.move_cmd.linear.x = .1
        if cent_x < screen_x-error:
            if VERBOSE:
                print("#left")
            self.move_cmd.angular.z = degree
        elif cent_x > (screen_x+error):
            if VERBOSE:
                print("right")
            self.move_cmd.angular.z = degree*-1
        else:
            if VERBOSE:
                print("straight")
            self.move_cmd.angular.z = 0
        if cent_x==0:
            self.stay_still()


if __name__ == "__main__":
    try:
        if VERBOSE:
            print("start")
        turtle_move()

    except:

        self.shutdown()
        rospy.loginfo("turtle_move terminated.")
